module.exports = {

    calcPrice : (cantidad, prceioFinal) =>
    {
        let res = (cantidad*prceioFinal)/50
        return res
    }

}