module.exports = {
    "databaseURI":"mongodb+srv://root:d3tt34mm@wishmaster.t9mkm.mongodb.net/magicteashop",
    "portExpress": 3000
  }